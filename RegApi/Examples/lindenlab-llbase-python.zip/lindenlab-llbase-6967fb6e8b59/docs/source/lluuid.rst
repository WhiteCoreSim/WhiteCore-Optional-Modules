lluuid
======

Python UUID helpers.

Constants
---------
.. data:: REGEX_STR

   Raw string to insert into your application's regular expression needs.


.. data:: NULL

   A simple UUID(int=0) null uuid.


Functions
---------

.. autofunction:: llbase.lluuid.generate

.. autofunction:: llbase.lluuid.is_str_uuid


