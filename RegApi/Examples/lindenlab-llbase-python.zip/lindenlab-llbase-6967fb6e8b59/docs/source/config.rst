Config
======

Utility module for parsing and using configuration files.

.. autofunction:: llbase.config.load

.. autofunction:: llbase.config.get

.. autofunction:: llbase.config.set

.. autofunction:: llbase.config.update

.. autoclass:: llbase.config.Config
   :members:
